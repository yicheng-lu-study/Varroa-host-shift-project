#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/data_best_model/batches/run_batch_002_boot7-12_estrep1-100.sh" "$@"
