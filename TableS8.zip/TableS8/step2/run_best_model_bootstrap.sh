#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# User settings. Leave a range empty to use the full range from config/config.yaml.
BOOT_BATCH_RANGE="${BOOT_BATCH_RANGE:-${BOOT_BATCH:-}}"
EST_REP_RANGE="${EST_REP_RANGE:-${EST_REP_BATCH:-}}"
REP_CHUNKS="${REP_CHUNKS:-}"
CORES="${CORES:-20}"

export BOOT_BATCH="${BOOT_BATCH_RANGE}"
export EST_REP_BATCH="${EST_REP_RANGE}"

export FSC_CODE_ROOT="${FSC_CODE_ROOT:-${SCRIPT_DIR}}"
export FSC_DATA_ROOT="${FSC_DATA_ROOT:-${SCRIPT_DIR}/data_best_model}"
export FSC_CONFIG="${FSC_CONFIG:-${SCRIPT_DIR}/config/config.yaml}"
DEFAULT_PACKED_ENV="${SCRIPT_DIR}/envs/project-fastsimcoal2"
if [ -z "${FSC_EXISTING_ENV:-}" ]; then
  FSC_EXISTING_ENV="${DEFAULT_PACKED_ENV}"
fi
export FSC_EXISTING_ENV
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-${FSC_DATA_ROOT}/.cache}"

RESTART_TIMES="${RESTART_TIMES:-3}"

if [ ! -x "${FSC_EXISTING_ENV}/bin/snakemake" ] && [ "${FSC_EXISTING_ENV}" = "${DEFAULT_PACKED_ENV}" ]; then
  PACKED_ENV_TARBALL="${SCRIPT_DIR}/envs/project-fastsimcoal2.linux-64.tar.gz"
  if [ -s "${PACKED_ENV_TARBALL}" ]; then
    mkdir -p "${FSC_EXISTING_ENV}"
    tar -xzf "${PACKED_ENV_TARBALL}" -C "${FSC_EXISTING_ENV}"
  fi
fi

if [ "${FSC_EXISTING_ENV}" = "${DEFAULT_PACKED_ENV}" ] && \
   [ -x "${FSC_EXISTING_ENV}/bin/conda-unpack" ] && \
   [ ! -e "${FSC_EXISTING_ENV}/.conda_unpacked" ]; then
  PATH="${FSC_EXISTING_ENV}/bin:${PATH}" "${FSC_EXISTING_ENV}/bin/conda-unpack"
  touch "${FSC_EXISTING_ENV}/.conda_unpacked"
fi

if [ ! -x "${FSC_EXISTING_ENV}/bin/snakemake" ]; then
  echo "Pack-local project-fastsimcoal2 environment not found: ${FSC_EXISTING_ENV}" >&2
  echo "Expected it under this pack, or set FSC_EXISTING_ENV explicitly." >&2
  exit 127
fi

export PATH="${FSC_EXISTING_ENV}/bin:${PATH}"
SNAKEMAKE_BIN="${SNAKEMAKE_BIN:-${FSC_EXISTING_ENV}/bin/snakemake}"

mkdir -p "${FSC_DATA_ROOT}"

if [ -n "${REP_CHUNKS}" ] && [ -z "${FSC_RUNNING_REP_CHUNK:-}" ]; then
  IFS="," read -r -a rep_chunks <<< "${REP_CHUNKS}"
  for rep_chunk in "${rep_chunks[@]}"; do
    rep_chunk="${rep_chunk//[[:space:]]/}"
    [ -n "${rep_chunk}" ] || continue
    echo "[$(date)] Running BOOT_BATCH_RANGE=${BOOT_BATCH_RANGE:-all} EST_REP_RANGE=${rep_chunk} CORES=${CORES}"
    BOOT_BATCH_RANGE="${BOOT_BATCH_RANGE}" EST_REP_RANGE="${rep_chunk}" CORES="${CORES}" \
      FSC_RUNNING_REP_CHUNK=1 "$0" "$@"
  done
  exit 0
fi

"${SNAKEMAKE_BIN}" \
  --snakefile "${SCRIPT_DIR}/Snakefile" \
  --directory "${FSC_DATA_ROOT}" \
  --cores "${CORES}" \
  --restart-times "${RESTART_TIMES}" \
  --rerun-incomplete \
  --printshellcmds \
  "$@"
