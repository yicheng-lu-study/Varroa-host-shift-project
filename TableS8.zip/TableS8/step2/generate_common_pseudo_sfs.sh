#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

# User settings. This script only generates pseudo SFS; EST_REP_RANGE is kept
# here so all launch scripts expose the same editable fields.
PSEUDO_SFS="${PSEUDO_SFS:-100}"
BOOT_BATCH_RANGE="${BOOT_BATCH_RANGE:-1-${PSEUDO_SFS}}"
EST_REP_RANGE="${EST_REP_RANGE:-1-10}"
CORES="${CORES:-20}"

DATA_ROOT="${FSC_DATA_ROOT:-${SCRIPT_DIR}/data_best_model}"
RUN_NAME="${RUN_NAME:-best_model_parametric_bootstrap_100x100_v1}"
OUTDIR="${OUTDIR:-${DATA_ROOT}/results/${RUN_NAME}}"
LOGDIR="${LOGDIR:-${DATA_ROOT}/logs/${RUN_NAME}}"

MODEL="${MODEL:-mig_botgrowth}"
BEST_REP="${BEST_REP:-25}"
BLOCK_LENGTH="${BLOCK_LENGTH:-200}"
CALLABLE_LENGTH="${CALLABLE_LENGTH:-37428127}"
SIMULATION_SEED_BASE="${SIMULATION_SEED_BASE:-${SIMULATION_SEED:-260740}}"

FSC_BIN="${FSC_BIN:-${SCRIPT_DIR}/bin/fsc28}"
BEST_RUN_DIR="${BEST_RUN_DIR:-${DATA_ROOT}/total_runs/rep${BEST_REP}}"
BEST_MAXL_PAR="${BEST_MAXL_PAR:-${BEST_RUN_DIR}/${MODEL}/${MODEL}_maxL.par}"
BOOT_PAR="${BOOT_PAR:-${OUTDIR}/best_rep/rep${BEST_REP}/${MODEL}_boot.par}"
BOOT_SIM_DIR="${BOOT_SIM_DIR:-${OUTDIR}/bootstrap_simulation/fsc_output}"
BOOT_OBS_DIR="${BOOT_OBS_DIR:-${OUTDIR}/bootstrap_obs}"
MANIFEST="${MANIFEST:-${BOOT_OBS_DIR}/manifest.tsv}"
SEED_MANIFEST="${SEED_MANIFEST:-${OUTDIR}/bootstrap_simulation/seed_manifest.tsv}"
SIM_DONE="${SIM_DONE:-${OUTDIR}/bootstrap_simulation/simulate.done}"
LOG_FILE="${LOG_FILE:-${LOGDIR}/bootstrap_simulation/generate_common_pseudo_sfs.log}"

mkdir -p "$(dirname "${BOOT_PAR}")" "${BOOT_SIM_DIR}" "${BOOT_OBS_DIR}" \
  "$(dirname "${SEED_MANIFEST}")" "$(dirname "${SIM_DONE}")" "$(dirname "${LOG_FILE}")"

if [ ! -x "${FSC_BIN}" ]; then
  echo "fastsimcoal2 executable not found or not executable: ${FSC_BIN}" >&2
  exit 127
fi

if [ ! -s "${BEST_MAXL_PAR}" ]; then
  echo "Best maxL par not found: ${BEST_MAXL_PAR}" >&2
  exit 2
fi

for required in \
  "${BEST_RUN_DIR}/${MODEL}.tpl" \
  "${BEST_RUN_DIR}/${MODEL}.est" \
  "${BEST_RUN_DIR}/${MODEL}_jointMAFpop1_0.obs" \
  "${BEST_RUN_DIR}/${MODEL}/${MODEL}.pv"
do
  if [ ! -s "${required}" ]; then
    echo "Required best-model input missing or empty: ${required}" >&2
    exit 2
  fi
done

{
  echo "[$(date)] generating bootstrap par"
  python3 "${SCRIPT_DIR}/scripts/make_bootstrap_par.py" \
    --input "${BEST_MAXL_PAR}" \
    --output "${BOOT_PAR}" \
    --block-length "${BLOCK_LENGTH}" \
    --callable-length "${CALLABLE_LENGTH}"

  echo "[$(date)] simulating pseudo-observed SFS files for boots ${BOOT_BATCH_RANGE} with independent seeds"
  python3 "${SCRIPT_DIR}/scripts/simulate_bootstrap_sfs.py" \
    --fsc "${FSC_BIN}" \
    --par "${BOOT_PAR}" \
    --output-dir "${BOOT_SIM_DIR}" \
    --boots "${BOOT_BATCH_RANGE}" \
    --model "${MODEL}" \
    --seed-base "${SIMULATION_SEED_BASE}" \
    --manifest "${SEED_MANIFEST}"
  touch "${SIM_DONE}"

  echo "[$(date)] normalizing pseudo-observed SFS files"
  python3 "${SCRIPT_DIR}/scripts/normalize_bootstrap_obs.py" \
    --simulation-dir "${BOOT_SIM_DIR}" \
    --output-dir "${BOOT_OBS_DIR}" \
    --boots "${BOOT_BATCH_RANGE}" \
    --model "${MODEL}" \
    --manifest "${MANIFEST}" \
    --simulation-manifest "${SEED_MANIFEST}"

  echo "[$(date)] done"
  echo "bootstrap par: ${BOOT_PAR}"
  echo "seed manifest: ${SEED_MANIFEST}"
  echo "manifest: ${MANIFEST}"
} > "${LOG_FILE}" 2>&1

cat <<EOF
Generated common pseudo SFS inputs.
Bootstrap par: ${BOOT_PAR}
Seed manifest: ${SEED_MANIFEST}
OBS manifest:  ${MANIFEST}
Log:           ${LOG_FILE}
EOF
