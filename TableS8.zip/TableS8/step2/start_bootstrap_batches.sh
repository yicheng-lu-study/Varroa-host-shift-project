#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

# User settings.
BATCH_1_BOOT_RANGE="${BATCH_1_BOOT_RANGE:-1-6}"
BATCH_2_BOOT_RANGE="${BATCH_2_BOOT_RANGE:-7-12}"
BATCH_3_BOOT_RANGE="${BATCH_3_BOOT_RANGE:-13-23}"
BATCH_4_BOOT_RANGE="${BATCH_4_BOOT_RANGE:-24-30}"
BATCH_1_CORES="${BATCH_1_CORES:-18}"
BATCH_2_CORES="${BATCH_2_CORES:-18}"
BATCH_3_CORES="${BATCH_3_CORES:-78}"
BATCH_4_CORES="${BATCH_4_CORES:-60}"
EST_REP_RANGE="${EST_REP_RANGE:-1-10}"
REP_CHUNKS="${REP_CHUNKS:-1-10,11-20,21-30,31-40,41-50,51-60,61-70,71-80,81-90,91-100}"
CORES="${CORES:-}"

MODE="${1:-help}"

LOGDIR="${SCRIPT_DIR}/data_best_model/launcher_logs"

mkdir -p "${LOGDIR}"

boot_range() {
  case "$1" in
    1) echo "${BATCH_1_BOOT_RANGE}" ;;
    2) echo "${BATCH_2_BOOT_RANGE}" ;;
    3) echo "${BATCH_3_BOOT_RANGE}" ;;
    4) echo "${BATCH_4_BOOT_RANGE}" ;;
    *) return 1 ;;
  esac
}

batch_cores() {
  case "$1" in
    1) echo "${BATCH_1_CORES}" ;;
    2) echo "${BATCH_2_CORES}" ;;
    3) echo "${BATCH_3_CORES}" ;;
    4) echo "${BATCH_4_CORES}" ;;
    *) return 1 ;;
  esac
}

start_one() {
  local id="$1"
  local boot_batch
  boot_batch="$(boot_range "${id}")"
  local cores
  cores="${CORES:-$(batch_cores "${id}")}"
  local log="${LOGDIR}/batch_${id}_boot${boot_batch}_estrep${EST_REP_RANGE}.nohup.log"
  local pidfile="${LOGDIR}/batch_${id}.pid"

  if [ -s "${pidfile}" ]; then
    local old_pid
    old_pid="$(cat "${pidfile}")"
    if kill -0 "${old_pid}" >/dev/null 2>&1; then
      echo "batch ${id} already appears to be running: pid=${old_pid}"
      return 0
    fi
  fi

  echo "Starting batch ${id}: BOOT_BATCH_RANGE=${boot_batch} EST_REP_RANGE=${EST_REP_RANGE} REP_CHUNKS=${REP_CHUNKS} CORES=${cores}; log=${log}"
  nohup bash -c '
    set -euo pipefail
    cd "$1"
    boot_batch="$2"
    est_rep_range="$3"
    rep_chunks="$4"
    cores="$5"
    if [ -n "${rep_chunks}" ]; then
      IFS="," read -r -a chunks <<< "${rep_chunks}"
      for chunk in "${chunks[@]}"; do
        chunk="${chunk//[[:space:]]/}"
        [ -n "${chunk}" ] || continue
        echo "[$(date)] Running BOOT_BATCH_RANGE=${boot_batch} EST_REP_RANGE=${chunk} CORES=${cores}"
        BOOT_BATCH_RANGE="${boot_batch}" EST_REP_RANGE="${chunk}" CORES="${cores}" ./run_best_model_bootstrap.sh
      done
    else
      echo "[$(date)] Running BOOT_BATCH_RANGE=${boot_batch} EST_REP_RANGE=${est_rep_range} CORES=${cores}"
      BOOT_BATCH_RANGE="${boot_batch}" EST_REP_RANGE="${est_rep_range}" CORES="${cores}" ./run_best_model_bootstrap.sh
    fi
  ' _ "${SCRIPT_DIR}" "${boot_batch}" "${EST_REP_RANGE}" "${REP_CHUNKS}" "${cores}" > "${log}" 2>&1 &
  echo "$!" > "${pidfile}"
  echo "batch ${id} pid=$!"
}

case "${MODE}" in
  1|2|3|4)
    start_one "${MODE}"
    ;;
  all)
    for id in 1 2 3 4; do
      start_one "${id}"
    done
    ;;
  status)
    echo "Recorded bootstrap batch pids:"
    for pidfile in "${LOGDIR}"/batch_*.pid; do
      [ -e "${pidfile}" ] || continue
      pid="$(cat "${pidfile}")"
      if kill -0 "${pid}" >/dev/null 2>&1; then
        echo "$(basename "${pidfile}") pid=${pid} running"
      else
        echo "$(basename "${pidfile}") pid=${pid} not running"
      fi
    done
    echo
    echo "Latest launcher logs:"
    ls -lh "${LOGDIR}"/*.nohup.log 2>/dev/null || true
    ;;
  help|-h|--help)
    cat <<EOF
Usage:
  ./start_bootstrap_batches.sh 1        # start batch 1 only
  ./start_bootstrap_batches.sh 2        # start batch 2 only
  ./start_bootstrap_batches.sh 3        # start batch 3 only
  ./start_bootstrap_batches.sh 4        # start batch 4 only
  ./start_bootstrap_batches.sh all      # start all four batches on this machine
  ./start_bootstrap_batches.sh status   # show running batch processes and logs

	Optional:
	  REP_CHUNKS=1-10,11-20,21-30 ./start_bootstrap_batches.sh 1
	  BATCH_1_BOOT_RANGE=1-10 BATCH_1_CORES=18 ./start_bootstrap_batches.sh 1
	  CORES=20 ./start_bootstrap_batches.sh all  # override all batch core counts

Logs:
  data_best_model/launcher_logs/batch_<id>.nohup.log
EOF
    ;;
  *)
    echo "Unknown mode: ${MODE}" >&2
    echo "Run ./start_bootstrap_batches.sh help" >&2
    exit 2
    ;;
esac
