#!/usr/bin/env python3

import argparse
import csv
import math
from pathlib import Path


TIME_COLUMNS = ["TFOUNDER", "TBOTEND", "TDIV", "TCONTACT"]


def parse_rate(value):
    label, rates = value.split(":", 1)
    low, high = rates.split(",", 1)
    return label, float(low), float(high)


def read_one(path):
    with Path(path).open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    return rows[0] if rows else {}


def as_float(value):
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(out):
        return None
    return out


def percentile(values, pct):
    if not values:
        return None
    values = sorted(values)
    if len(values) == 1:
        return values[0]
    pos = (len(values) - 1) * pct / 100.0
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return values[lo]
    frac = pos - lo
    return values[lo] * (1.0 - frac) + values[hi] * frac


def add_calendar(row, rates):
    for col in TIME_COLUMNS:
        value = as_float(row.get(col))
        if value is None:
            continue
        for label, low_rate, high_rate in rates:
            lo = min(low_rate, high_rate)
            hi = max(low_rate, high_rate)
            if lo <= 0:
                continue
            row[f"{col}_years_{label}_min"] = f"{value / hi:.10g}"
            row[f"{col}_years_{label}_max"] = f"{value / lo:.10g}"


def write_table(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--all-runs", required=True)
    parser.add_argument("--best-runs", required=True)
    parser.add_argument("--ci-summary", required=True)
    parser.add_argument("--parameters", nargs="+", required=True)
    parser.add_argument("--aliases", nargs="*", default=[])
    parser.add_argument("--generation-rates", nargs="*", default=[])
    args = parser.parse_args()

    rates = [parse_rate(item) for item in args.generation_rates]
    aliases = dict(item.split("=", 1) for item in args.aliases)

    rows = [read_one(path) for path in args.inputs]
    rows = [row for row in rows if row]
    for row in rows:
        add_calendar(row, rates)
    write_table(args.all_runs, rows)

    best = []
    by_bootstrap = {}
    for row in rows:
        if row.get("status") != "ok":
            continue
        lhood = as_float(row.get("MaxEstLhood"))
        if lhood is None:
            continue
        boot = row.get("bootstrap")
        current = by_bootstrap.get(boot)
        if current is None or lhood > current[0]:
            by_bootstrap[boot] = (lhood, row)
    for _, row in sorted(by_bootstrap.values(), key=lambda item: int(item[1]["bootstrap"])):
        best.append(row)
    write_table(args.best_runs, best)

    ci_rows = []
    for param in args.parameters:
        values = [as_float(row.get(param)) for row in best]
        values = [value for value in values if value is not None]
        if not values:
            continue
        ci_rows.append(
            {
                "parameter": param,
                "reference_name": aliases.get(param, param),
                "n": str(len(values)),
                "mean": f"{sum(values) / len(values):.10g}",
                "p2_5": f"{percentile(values, 2.5):.10g}",
                "p50": f"{percentile(values, 50):.10g}",
                "p97_5": f"{percentile(values, 97.5):.10g}",
                "min": f"{min(values):.10g}",
                "max": f"{max(values):.10g}",
            }
        )
    write_table(args.ci_summary, ci_rows)


if __name__ == "__main__":
    main()
