#!/usr/bin/env python3

import argparse
from pathlib import Path


def require_nonempty(path):
    path = Path(path)
    if not path.exists():
        raise SystemExit(f"missing required input: {path}")
    if path.stat().st_size == 0:
        raise SystemExit(f"required input is empty: {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--paths", nargs="+", required=True)
    args = parser.parse_args()
    for path in args.paths:
        require_nonempty(path)


if __name__ == "__main__":
    main()
