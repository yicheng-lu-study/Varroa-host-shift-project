#!/usr/bin/env python3

import argparse
import csv
import os
import re
import shutil
from pathlib import Path


def natural_key(path):
    parts = re.split(r"(\d+)", str(path))
    return [int(part) if part.isdigit() else part for part in parts]


def display_path(path):
    return os.path.relpath(path, Path.cwd())


def resolve_path(path):
    path = Path(path)
    if path.is_absolute():
        return path
    candidates = [Path.cwd() / path, Path.cwd().parent / path]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0]


def parse_boot_tokens(values):
    boots = []
    seen = set()
    for value in values:
        for part in str(value).split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                start_text, end_text = part.split("-", 1)
                items = range(int(start_text), int(end_text) + 1)
            else:
                items = [int(part)]
            for item in items:
                if item not in seen:
                    seen.add(item)
                    boots.append(item)
    return boots


def read_simulation_manifest(path):
    with Path(path).open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    return {int(row["bootstrap"]): row for row in rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--simulation-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--boots", nargs="+", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--simulation-manifest", default=None)
    args = parser.parse_args()

    boots = parse_boot_tokens(args.boots)
    if not boots or any(value <= 0 for value in boots):
        raise ValueError("--boots must contain positive integers")

    sim_dir = Path(args.simulation_dir)
    simulation_rows = None
    candidates = []
    if args.simulation_manifest:
        simulation_rows = read_simulation_manifest(args.simulation_manifest)
        missing = [boot for boot in boots if boot not in simulation_rows]
        if missing:
            raise SystemExit(
                f"Missing bootstraps in simulation manifest: "
                f"{','.join(str(boot) for boot in missing)}"
            )
    else:
        candidates = sorted(
            [
                path
                for path in sim_dir.rglob("*jointMAFpop1_0.obs")
                if path.is_file()
            ],
            key=natural_key,
        )
        max_boot = max(boots)
        if len(candidates) < max_boot:
            raise SystemExit(
                f"Expected at least {max_boot} simulated obs files under {sim_dir}, "
                f"found {len(candidates)}"
            )

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = Path(args.manifest)
    manifest.parent.mkdir(parents=True, exist_ok=True)

    with manifest.open("w", encoding="utf-8") as handle:
        handle.write("bootstrap\tseed\tsource\tstandard_obs\tseed_file\n")
        for boot in boots:
            seed = ""
            if simulation_rows is not None:
                simulation_row = simulation_rows[boot]
                source = resolve_path(simulation_row["obs"])
                seed = simulation_row.get("seed", "")
            else:
                source = candidates[boot - 1]
            dest = out_dir / f"boot{boot}" / f"{args.model}_jointMAFpop1_0.obs"
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            seed_file = dest.parent / "seed.txt"
            seed_file.write_text(f"{seed}\n", encoding="utf-8")
            handle.write(
                f"{boot}\t{seed}\t{display_path(source)}\t"
                f"{display_path(dest)}\t{display_path(seed_file)}\n"
            )


if __name__ == "__main__":
    main()
