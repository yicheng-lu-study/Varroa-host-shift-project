#!/usr/bin/env python3

import argparse
import csv
import os
import shutil
import subprocess
from pathlib import Path


def fsc_seed(seed_base, boot):
    raw = seed_base + boot
    return ((raw - 1) % 1000000) + 1


def display_path(path):
    return os.path.relpath(path, Path.cwd())


def parse_boot_tokens(values):
    boots = []
    seen = set()
    for value in values:
        for part in str(value).split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                start_text, end_text = part.split("-", 1)
                items = range(int(start_text), int(end_text) + 1)
            else:
                items = [int(part)]
            for item in items:
                if item not in seen:
                    seen.add(item)
                    boots.append(item)
    return boots


def find_obs(workdir):
    candidates = sorted(
        path for path in Path(workdir).rglob("*jointMAFpop1_0.obs") if path.is_file()
    )
    if not candidates:
        raise SystemExit(f"no simulated obs file found under {workdir}")
    return candidates[0]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fsc", required=True)
    parser.add_argument("--par", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--boots", nargs="+", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--seed-base", type=int, required=True)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args()

    boots = parse_boot_tokens(args.boots)
    if not boots or any(value <= 0 for value in boots):
        raise ValueError("--boots must contain positive integers")

    fsc = Path(args.fsc)
    if not fsc.exists():
        raise SystemExit(f"fastsimcoal2 executable not found: {fsc}")

    source_par = Path(args.par)
    if not source_par.exists():
        raise SystemExit(f"bootstrap par not found: {source_par}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest = Path(args.manifest)
    manifest.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for boot in boots:
        seed = fsc_seed(args.seed_base, boot)
        workdir = output_dir / f"boot{boot}"
        if workdir.exists():
            shutil.rmtree(workdir)
        workdir.mkdir(parents=True)

        par_name = f"{args.model}_boot.par"
        par_path = workdir / par_name
        shutil.copy2(source_par, par_path)

        command = [
            str(fsc),
            "-i",
            par_name,
            "-n",
            "1",
            "-j",
            "-m",
            "-s0",
            "-x",
            "-I",
            "-q",
            "-r",
            str(seed),
        ]
        subprocess.run(command, cwd=workdir, check=True)
        seed_file = workdir / "seed.txt"
        seed_file.write_text(f"{seed}\n", encoding="utf-8")

        obs = find_obs(workdir)
        rows.append(
            {
                "bootstrap": str(boot),
                "seed": str(seed),
                "workdir": display_path(workdir),
                "par": display_path(par_path),
                "obs": display_path(obs),
                "seed_file": display_path(seed_file),
            }
        )

    with manifest.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["bootstrap", "seed", "workdir", "par", "obs", "seed_file"],
            delimiter="\t",
        )
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
