#!/usr/bin/env python3

import argparse
import csv
import os
from pathlib import Path


def read_table(path):
    rows = [line.strip() for line in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
    if len(rows) < 2:
        return {}
    header = rows[0].split()
    values = rows[1].split()
    return dict(zip(header, values))


def display_path(path):
    return os.path.relpath(path, Path.cwd())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--bootstrap", required=True)
    parser.add_argument("--replicate", required=True)
    parser.add_argument("--projection", required=True)
    parser.add_argument("--scenario", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--mu-token", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    candidates = sorted(run_dir.rglob("*.bestlhoods"))
    row = {
        "bootstrap": args.bootstrap,
        "replicate": args.replicate,
        "projection": args.projection,
        "scenario": args.scenario,
        "model": args.model,
        "mu_token": args.mu_token,
        "status": "ok" if candidates else "missing_bestlhoods",
        "bestlhoods_path": display_path(candidates[0]) if candidates else "",
    }
    if candidates:
        row.update(read_table(candidates[0]))

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()), delimiter="\t")
        writer.writeheader()
        writer.writerow(row)


if __name__ == "__main__":
    main()
