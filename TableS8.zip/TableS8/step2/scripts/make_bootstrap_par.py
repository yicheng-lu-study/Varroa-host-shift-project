#!/usr/bin/env python3

import argparse
import math
from pathlib import Path


def next_data_line(lines, start):
    for idx in range(start, len(lines)):
        stripped = lines[idx].strip()
        if stripped and not stripped.startswith("//"):
            return idx
    raise ValueError("could not find expected data line")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--block-length", type=int, required=True)
    parser.add_argument("--callable-length", type=int, required=True)
    parser.add_argument("--num-loci", type=int, default=None)
    args = parser.parse_args()

    if args.block_length <= 0:
        raise ValueError("--block-length must be positive")
    if args.callable_length <= 0:
        raise ValueError("--callable-length must be positive")

    num_loci = args.num_loci
    if num_loci is None:
        num_loci = int(math.ceil(args.callable_length / args.block_length))

    lines = Path(args.input).read_text(encoding="utf-8").splitlines()
    changed_loci = False
    changed_block = False

    for idx, line in enumerate(lines):
        if line.strip().startswith("//Number of independent loci"):
            target = next_data_line(lines, idx + 1)
            lines[target] = f"{num_loci} 0"
            changed_loci = True
        if line.strip().startswith("//per Block:data type"):
            target = next_data_line(lines, idx + 1)
            parts = lines[target].split()
            if len(parts) < 4:
                raise ValueError(f"cannot parse block line: {lines[target]}")
            mu = parts[3]
            suffix = " ".join(parts[4:]) if len(parts) > 4 else "OUTEXP"
            lines[target] = f"DNA  {args.block_length}   0   {mu} {suffix}"
            changed_block = True

    if not changed_loci:
        raise ValueError("did not find independent-loci block in input par")
    if not changed_block:
        raise ValueError("did not find per-block data line in input par")

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
