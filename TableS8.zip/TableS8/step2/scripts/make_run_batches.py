#!/usr/bin/env python3

import argparse
import math
from pathlib import Path


def ranges(total, batches):
    width = int(math.ceil(total / batches))
    result = []
    start = 1
    while start <= total:
        end = min(total, start + width - 1)
        result.append((start, end))
        start = end + 1
    return result


def fmt_range(pair):
    start, end = pair
    return str(start) if start == end else f"{start}-{end}"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir", default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--total-boots", type=int, default=100)
    parser.add_argument("--total-est-reps", type=int, default=10)
    parser.add_argument("--boot-batches", type=int, default=4)
    parser.add_argument("--est-rep-batches", type=int, default=1)
    parser.add_argument("--cores", type=int, default=20)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    default_project_dir = Path(__file__).resolve().parents[1]
    project_dir = Path(args.project_dir).resolve() if args.project_dir else default_project_dir
    outdir = Path(args.output_dir).resolve() if args.output_dir else project_dir / "data_best_model" / "batches"

    boot_ranges = ranges(args.total_boots, args.boot_batches)
    est_ranges = ranges(args.total_est_reps, args.est_rep_batches)
    outdir.mkdir(parents=True, exist_ok=True)

    manifest = outdir / "batch_manifest.tsv"
    with manifest.open("w", encoding="utf-8") as handle:
        handle.write("batch_script\tboot_batch\test_rep_batch\tcores\n")
        idx = 0
        for boot_range in boot_ranges:
            for est_range in est_ranges:
                idx += 1
                boot_text = fmt_range(boot_range)
                est_text = fmt_range(est_range)
                script = outdir / f"run_batch_{idx:03d}_boot{boot_text}_estrep{est_text}.sh"
                command = './run_best_model_bootstrap.sh'
                if args.dry_run:
                    command += " -n"
                script.write_text(
                    "#!/usr/bin/env bash\n"
                    "set -euo pipefail\n"
                    "\n"
                    "# User settings.\n"
                    f'BOOT_BATCH_RANGE="${{BOOT_BATCH_RANGE:-{boot_text}}}"\n'
                    f'EST_REP_RANGE="${{EST_REP_RANGE:-{est_text}}}"\n'
                    'REP_CHUNKS="${REP_CHUNKS:-}"\n'
                    f'CORES="${{CORES:-{args.cores}}}"\n'
                    "\n"
                    'PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"\n'
                    'cd "${PROJECT_DIR}"\n'
                    "\n"
                    'if [ -n "${REP_CHUNKS}" ]; then\n'
                    '  IFS="," read -r -a rep_chunks <<< "${REP_CHUNKS}"\n'
                    '  for rep_chunk in "${rep_chunks[@]}"; do\n'
                    '    rep_chunk="${rep_chunk//[[:space:]]/}"\n'
                    '    [ -n "${rep_chunk}" ] || continue\n'
                    '    echo "Running BOOT_BATCH_RANGE=${BOOT_BATCH_RANGE} EST_REP_RANGE=${rep_chunk} CORES=${CORES}"\n'
                    '    BOOT_BATCH_RANGE="${BOOT_BATCH_RANGE}" EST_REP_RANGE="${rep_chunk}" CORES="${CORES}" \\\n'
                    f"      {command}\n"
                    '  done\n'
                    'else\n'
                    '  export BOOT_BATCH_RANGE EST_REP_RANGE CORES\n'
                    f"  {command}\n"
                    'fi\n',
                    encoding="utf-8",
                )
                script.chmod(0o755)
                handle.write(f"{script.name}\t{boot_text}\t{est_text}\t{args.cores}\n")


if __name__ == "__main__":
    main()
