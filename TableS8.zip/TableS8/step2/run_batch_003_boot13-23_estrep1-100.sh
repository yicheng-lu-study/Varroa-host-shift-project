#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/data_best_model/batches/run_batch_003_boot13-23_estrep1-100.sh" "$@"
