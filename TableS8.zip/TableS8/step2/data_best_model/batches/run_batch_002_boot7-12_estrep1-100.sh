#!/usr/bin/env bash
set -euo pipefail

# User settings.
BOOT_BATCH_RANGE="${BOOT_BATCH_RANGE:-7-12}"
EST_REP_RANGE="${EST_REP_RANGE:-1-100}"
REP_CHUNKS="${REP_CHUNKS:-1-10,11-20,21-30,31-40,41-50,51-60,61-70,71-80,81-90,91-100}"
CORES="${CORES:-18}"

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${PROJECT_DIR}"

if [ -n "${REP_CHUNKS}" ]; then
  IFS="," read -r -a rep_chunks <<< "${REP_CHUNKS}"
  for rep_chunk in "${rep_chunks[@]}"; do
    rep_chunk="${rep_chunk//[[:space:]]/}"
    [ -n "${rep_chunk}" ] || continue
    echo "Running BOOT_BATCH_RANGE=${BOOT_BATCH_RANGE} EST_REP_RANGE=${rep_chunk} CORES=${CORES}"
    BOOT_BATCH_RANGE="${BOOT_BATCH_RANGE}" EST_REP_RANGE="${rep_chunk}" CORES="${CORES}" \
      ./run_best_model_bootstrap.sh "$@"
  done
else
  export BOOT_BATCH_RANGE EST_REP_RANGE CORES
  ./run_best_model_bootstrap.sh "$@"
fi
