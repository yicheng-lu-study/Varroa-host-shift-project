#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${SCRIPT_DIR}/data_best_model/batches/run_batch_001_boot1-6_estrep1-100.sh" "$@"
