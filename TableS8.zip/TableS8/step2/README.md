# project_server_best_model100x100

This workflow starts after the original 100 fastsimcoal2 replicates have already
been screened. It uses the selected best run, `rep25`, to perform the reference
parametric bootstrap procedure.

All generated data are written under:

```text
./data_best_model
```

The copied best input is:

```text
data_best_model/total_runs/rep25/mig_botgrowth/mig_botgrowth_maxL.par
```

The original observed SFS expected by the copied best run is:

```text
data_best_model/total_runs/rep25/mig_botgrowth_jointMAFpop1_0.obs
```

This file must be non-empty. The pack is intended to be self-contained, so this
file should be present under `data_best_model/total_runs/rep25` before the pack
is distributed.

Default bootstrap settings allow a 100x100 workload:

- 100 pseudo-observed SFS datasets simulated from the best `maxL.par`
- best-run projection is `18x18`
- pseudo SFS simulation runs once per bootstrap with an independent `-r` seed
- up to 100 parameter-estimation replicates per pseudo SFS
- generated batch scripts default to `EST_REP_RANGE=1-10` for the first pass
- `-n 1000000 -l 20 -L 150`
- Snakemake cores are set by each launch script, 6 fastsimcoal2 threads per estimation run
- bootstrap estimation starts from the best-run `.pv` with `--initValues`
- deterministic fastsimcoal2 seeds via `-r`

Run a dry-run:

```bash
CORES=1 ./run_best_model_bootstrap.sh -n
```

Run the workflow:

```bash
CORES=20 ./run_best_model_bootstrap.sh
```

The launcher uses the pack-local environment by default:

```text
envs/project-fastsimcoal2
```

If this directory is missing, the launcher will try to extract:

```text
envs/project-fastsimcoal2.linux-64.tar.gz
```

Set `FSC_EXISTING_ENV` only if a machine intentionally uses a separately
managed environment.

For a small pilot, limit the generated DAG without editing the config:

```bash
BOOT_BATCH_RANGE=1 EST_REP_RANGE=1 CORES=1 ./run_best_model_bootstrap.sh -n
```

Generate per-machine batch scripts before running:

```bash
python3 scripts/make_run_batches.py --boot-batches 5 --cores 20
```

This writes scripts and a manifest under:

```text
data_best_model/batches
```

Example split:

```text
run_batch_001_boot1-6_estrep1-100.sh     # CORES=18
run_batch_002_boot7-12_estrep1-100.sh    # CORES=18
run_batch_003_boot13-23_estrep1-100.sh   # CORES=78
run_batch_004_boot24-30_estrep1-100.sh   # CORES=60
```

Run shared inputs once before distributing batches. This step is a plain bash
script, not a Snakemake target:

```bash
./generate_common_pseudo_sfs.sh
```

Then run each batch script on a separate machine. Batch summaries are written to
`summary/batches/<batch-label>/` to avoid cross-machine overwrites.

To run estimation replicates sequentially in chunks, set `REP_CHUNKS`. The next
chunk starts only after the previous Snakemake run finishes successfully:

```bash
./data_best_model/batches/run_batch_001_boot1-6_estrep1-100.sh
```

The launcher supports the same setting:

```bash
./start_bootstrap_batches.sh 1
```

At this stage the VCF is not required. The workflow only needs the best
fastsimcoal2 files already copied into `data_best_model/total_runs/rep25`, the
existing `project-fastsimcoal2` environment, and the `fsc28` executable.
The best-run initial values file is:

```text
data_best_model/total_runs/rep25/mig_botgrowth/mig_botgrowth.pv
```

Seed settings are in `config/config.yaml`:

```text
bootstrap.simulation_seed_base
bootstrap.estimation_seed_base
```

Each pseudo SFS writes its seed to `bootstrap_obs/boot*/seed.txt` and
`bootstrap_simulation/seed_manifest.tsv`. Each estimation run also writes the
actual seed to `seed.txt`.
