# fastsimcoal2 workflow for popA/popB divergence inference

This Snakemake workflow reuses the neutral VCF, population map, and callable
length generated in `F:\project_dadi` to infer the divergence history of popA
and popB with fastsimcoal2.

## Current pilot defaults

- Input VCF: `/mnt/f/project_dadi/results/neutral_sites_v1/vcf/neutral.targets.vcf.gz`
- Populations: `AcK1-CHN` as popA and `AmK1-core` as popB
- SFS: folded 2D joint MAF, projected to `18x18`
- Mutation rate: `8e-10`
- Models: split models, recent founder models, and old split with recent contact
  models; all time parameters are estimated in generations without a 50-100 year
  constraint.
- Search: 20 independent fastsimcoal2 runs per model/mutation-rate/projection

## Run

Run from the project directory with the `project-fastsimcoal2` conda
environment. The configs point to the local executable at
`/mnt/f/project_2608_time/bin/fsc28`.

```bash
conda run -n project-fastsimcoal2 snakemake -s Snakefile-722 --cores 16
```

For the host-jump all-sites workflow:

```bash
FSC_CONFIG=config/config_2608_time.yaml conda run -n project-fastsimcoal2 snakemake -s Snakefile-722 --cores 16
```

## Main outputs

- `results/fsc_neutral_pilot_v1/obs/18x18/popA_popB_jointMAFpop1_0.obs`
- `results/fsc_neutral_pilot_v1/runs/{projection}/{model}/mu{mu}/rep{rep}/`
- `results/fsc_neutral_pilot_v1/summary/all_runs.tsv`
- `results/fsc_neutral_pilot_v1/summary/overall_best.tsv`

The summary tables include calendar conversions for time parameters using the
configured generation rates:

- Ac: 3-5 generations/year
- Am: 10-15 generations/year
