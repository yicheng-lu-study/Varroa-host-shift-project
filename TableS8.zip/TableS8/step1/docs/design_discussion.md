# fastsimcoal2 design discussion

## What is fixed in the current scaffold

The workflow starts from the same neutral-site inputs used by the dadi project:
the neutral target VCF, the `AcK1-CHN` / `AmK1-core` population map, and the
neutral callable length. The `.obs` builder uses dadi's VCF-to-SFS machinery for
consistency with the dadi analysis, then rewrites the monomorphic cell as
`callable_length - projected_segregating_sites` so fastsimcoal2 can estimate
absolute Ne/time under a configured mutation rate.

The demographic models mirror the dadi comparison:

- `split_no_migration`
- `split_symmetric_migration`
- `split_asymmetric_migration`
- `recent_founder_no_migration`
- `recent_founder_symmetric_migration`
- `recent_founder_asymmetric_migration`
- `old_split_recent_symmetric_contact`
- `old_split_recent_asymmetric_contact`

The historical event convention is fastsimcoal2's backward-time convention.
For split models, population 1 merges into population 0 at `TDIV`, and the
ancestral size is set with `absoluteResize` to `NANC`. For recent-contact
models, current migration is active until `TCONTACT`, then migration is set to
zero until the older split at `TDIV`.

For founder models, population 1 is treated as the newly founded lineage. The
model estimates:

- `TFOUNDER`: time of founding/split in generations before present
- `TBOTEND`: time at which the founder bottleneck ends
- `NFOUND`: founder bottleneck effective size
- `NPOP1`, `NPOP2`: current population sizes
- `MIG12`, `MIG21`: post-founder migration rates, if present

These founder models are exploratory. `TFOUNDER` is not constrained to 50-100
years; the workflow estimates it in generations and then converts it to calendar
year ranges using the configured generation rates.

## Settings to decide before a formal run

1. Projection: keep `18x18` for the first pilot, then compare `14x14`,
   and `18x18` as in dadi if convergence looks stable.
2. Mutation rate grid: current pilot uses `8e-10`; formal comparison should
   probably include `2e-10`, `4e-10`, `6e-10`, and `8e-10` to match dadi.
3. Neutral definition: current scaffold uses `neutral_sites_v1`; we can add the
   multi-scheme neutral sets from `neutral_sites_multi_light_v1` once the
   fastsimcoal2 template is validated.
4. Search intensity: current pilot uses 20 replicates, `100000` simulations and
   40 ECM cycles; formal fits usually need more, for example 50-100 replicates
   and more simulations/cycles for the best candidate models.
5. Parameter bounds: current Ne, time and migration ranges are deliberately
   broad. We should tighten them after a pilot run if estimates pile up at
   boundaries.
6. Calendar interpretation: Ac is currently configured as 3-5 generations/year
   and Am as 10-15 generations/year. A fitted value such as `TFOUNDER = 600`
   generations would be reported as 120-200 years on the Ac clock and 40-60
   years on the Am clock.
7. Model ranking: use maximum estimated likelihood across independent runs, then
   compare AIC-like criteria only after confirming fastsimcoal2 output columns
   and free-parameter counts are parsed consistently.
