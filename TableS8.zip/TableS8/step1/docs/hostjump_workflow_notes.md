# project_2608_time host-jump fsc workflow notes

This workflow keeps generated files under `/mnt/f/project_2608_time`.

## Reference source

Reference workflow:

`/mnt/c/Users/FishY/Desktop/varroa-host-jump-master`

The demographic setup follows the reference fastsimcoal2 host-switch models:

- `div_nobot`: divergence / host jump, no migration, no bottleneck growth
- `mig_nobot`: divergence / host jump with asymmetric migration
- `div_botgrowth`: founder bottleneck with growth, no migration
- `mig_botgrowth`: founder bottleneck with growth and asymmetric migration

## Population orientation

The model follows the reference convention:

- deme 0 = novel / founder population: `AmK1-core`
- deme 1 = source population: `AcK1-CHN`

Thus the founder event is rendered as:

```text
TFOUNDER 0 1 1 RESJUMP 0 ...
```

Backward in time, lineages from deme 0 move into deme 1.

## Neutral all-sites filtering

The workflow starts from an all-sites VCF and builds a neutral subset before SFS construction.
The current configuration uses:

```text
/mnt/f/output_705_pi/vcf/mm80/pixy.filtered.allsites.vcf.gz
```

and excludes gene +/- 50 kb regions using the reference file:

```text
data/reference/gene_Vdes_3_50kb.txt
```

The filtering logic mirrors the reference workflow:

- keep only target populations from the popmap
- exclude gene +/- 50 kb regions
- remove indels
- keep biallelic sites
- require complete data by default with `--max-missing 1.0`

The filtered all-sites VCF is counted to obtain callable length. For dadi SFS parsing,
the workflow writes a temporary variant-only VCF because all-sites VCF records often have
`ALT=.` for invariant sites. Monomorphic counts are then restored from callable length.

## fastsimcoal2 settings

The default configuration follows the reference scale:

- 100 independent replicates
- `-n 1000000`
- `-l 20`
- `-L 100`
- `-c 10`

Mutation rates:

```text
1e-11, 2e-10, 4e-10, 6e-10, 8e-10
```

These settings are intentionally heavy. For pilot testing, reduce replicates and
`num_sims` in `config/config_2608_time.yaml`.
