//Parameters for the coalescence simulation program : fsimcoal2.exe
2 samples to simulate :
//Population effective sizes (number of genes)
NPOP0
NPOP1
//Samples sizes and samples age 
18
18
//Growth rates	: negative growth implies population expansion
GROWTH0
0
//Number of migration matrices : 0 implies no migration between demes
2
//Migration matrix 0
0 M0TO1
M1TO0 0
//Migration matrix 1: No migration
0 0
0 0
//historical event: time, source, sink, migrants, new deme size, new growth rate, migration matrix index
2 historical event
TBOTEND 0 0 0 RESBOT 0 1
TFOUNDER 0 1 1 RESJUMP 0 1
//Number of independent loci [chromosome] 
1 0
//Per chromosome: Number of contiguous linkage Block: a block is a set of contiguous loci
1
//per Block:data type, number of loci, per generation recombination and mutation rates and optional parameters
FREQ  1   0   8e-10 OUTEXP
