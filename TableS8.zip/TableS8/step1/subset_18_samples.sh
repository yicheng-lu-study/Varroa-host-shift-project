#!/usr/bin/env bash
set -euo pipefail

# Build a neutral 18-sample all-sites VCF for fastsimcoal2.
#
# Input is the basic-filtered all-sites branch, before pixy-specific
# variant filters such as MAF/MAC filtering.
# Run from anywhere:
#   bash /mnt/f/project_2608_time/subset_18_samples.sh

PROJECT_DIR="/mnt/f/project_2608_time"
INPUT_DIR="/mnt/f/output_705_pi/vcf/basic/mm80"
GENE_EXCLUDE_BED="${PROJECT_DIR}/data/reference/gene_Vdes_3_50kb.txt"
POP_TABLE="/mnt/f/project_dadi/data/observed/populations-CHN-AcK1-AmK1.txt"
POP_IDS=("AmK1-core" "AcK1-CHN")
CHROMS=(
    "NW_019211454.1"
    "NW_019211455.1"
    "NW_019211456.1"
    "NW_019211457.1"
    "NW_019211458.1"
    "NW_019211459.1"
    "NW_019211460.1"
)

OUT_DIR="${PROJECT_DIR}/results/fsc_allsites_hostjump_v1/basic_mm80_neutral18"
LOG_DIR="${PROJECT_DIR}/logs/fsc_allsites_hostjump_v1/basic_mm80_neutral18"
KEEP_FILE="${OUT_DIR}/keep.samples.txt"
SUBSET_DIR="${OUT_DIR}/subset18_per_chrom"
FILTERED_DIR="${OUT_DIR}/filtered_per_chrom"
FINAL_VCF="${OUT_DIR}/AmCore_AcCHN.basic_mm80.neutral.18samples.vcf.gz"

mkdir -p "${OUT_DIR}" "${LOG_DIR}" "${SUBSET_DIR}" "${FILTERED_DIR}"

count_samples() {
    zgrep -m1 '^#CHROM' "$1" \
        | tr '\t' '\n' \
        | tail -n +10 \
        | wc -l
}

for cmd in python3 vcftools bgzip tabix zgrep gzip awk wc; do
    if ! command -v "${cmd}" >/dev/null 2>&1; then
        echo "ERROR: required command not found: ${cmd}" >&2
        exit 1
    fi
done

for path in "${INPUT_DIR}" "${GENE_EXCLUDE_BED}" "${POP_TABLE}" "${PROJECT_DIR}/scripts/make_keep_samples.py"; do
    if [[ ! -e "${path}" ]]; then
        echo "ERROR: required input not found: ${path}" >&2
        exit 1
    fi
done

for chrom in "${CHROMS[@]}"; do
    input_vcf="${INPUT_DIR}/${chrom}.basic.allsites.vcf.gz"
    input_tbi="${input_vcf}.tbi"
    if [[ ! -s "${input_vcf}" ]]; then
        echo "ERROR: missing input VCF: ${input_vcf}" >&2
        exit 1
    fi
    if [[ ! -s "${input_tbi}" ]]; then
        echo "ERROR: missing input VCF index: ${input_tbi}" >&2
        exit 1
    fi
done

echo "[1/6] Writing keep-sample list: ${KEEP_FILE}"
python3 "${PROJECT_DIR}/scripts/make_keep_samples.py" \
    --population-table "${POP_TABLE}" \
    --pop-ids "${POP_IDS[@]}" \
    --output "${KEEP_FILE}" \
    > "${LOG_DIR}/make_keep_samples.log" 2>&1

echo "[2/6] Subsetting each chromosome to 18 samples"
for chrom in "${CHROMS[@]}"; do
    input_vcf="${INPUT_DIR}/${chrom}.basic.allsites.vcf.gz"
    subset_vcf="${SUBSET_DIR}/${chrom}.basic_mm80.18samples.vcf.gz"
    log_file="${LOG_DIR}/${chrom}.subset18.log"

    echo "  - ${chrom}"
    vcftools \
        --gzvcf "${input_vcf}" \
        --keep "${KEEP_FILE}" \
        --recode \
        --recode-INFO-all \
        --stdout \
        2> "${log_file}" \
        | bgzip -c > "${subset_vcf}"
    tabix -f -p vcf "${subset_vcf}"

    subset_sample_count="$(count_samples "${subset_vcf}")"
    if [[ "${subset_sample_count}" -ne 18 ]]; then
        echo "ERROR: expected 18 samples in ${subset_vcf}, got ${subset_sample_count}" >&2
        echo "Check log: ${log_file}" >&2
        exit 1
    fi
done

echo "[3/6] Filtering the 18-sample per-chromosome VCFs"
for chrom in "${CHROMS[@]}"; do
    subset_vcf="${SUBSET_DIR}/${chrom}.basic_mm80.18samples.vcf.gz"
    filtered_vcf="${FILTERED_DIR}/${chrom}.basic_mm80.neutral.18samples.vcf.gz"
    log_file="${LOG_DIR}/${chrom}.filter_neutral.log"

    echo "  - ${chrom}"
    vcftools \
        --gzvcf "${subset_vcf}" \
        --exclude-bed "${GENE_EXCLUDE_BED}" \
        --max-missing 1.0 \
        --remove-indels \
        --max-alleles 2 \
        --recode \
        --recode-INFO-all \
        --stdout \
        2> "${log_file}" \
        | bgzip -c > "${filtered_vcf}"
    tabix -f -p vcf "${filtered_vcf}"
done

echo "[4/6] Merging filtered chromosomes: ${FINAL_VCF}"
if command -v bcftools >/dev/null 2>&1; then
    per_chrom_vcfs=()
    for chrom in "${CHROMS[@]}"; do
        per_chrom_vcfs+=("${FILTERED_DIR}/${chrom}.basic_mm80.neutral.18samples.vcf.gz")
    done
    bcftools concat \
        -Oz \
        -o "${FINAL_VCF}" \
        "${per_chrom_vcfs[@]}" \
        > "${LOG_DIR}/merge_bcftools.log" 2>&1
else
    first_vcf="${FILTERED_DIR}/${CHROMS[0]}.basic_mm80.neutral.18samples.vcf.gz"
    {
        gzip -cd "${first_vcf}" | awk '/^#/ {print}'
        for chrom in "${CHROMS[@]}"; do
            gzip -cd "${FILTERED_DIR}/${chrom}.basic_mm80.neutral.18samples.vcf.gz" \
                | awk '!/^#/'
        done
    } | bgzip -c > "${FINAL_VCF}"
fi
tabix -f -p vcf "${FINAL_VCF}"

echo "[5/6] Counting callable records"
python3 "${PROJECT_DIR}/scripts/count_vcf_records.py" \
    --vcf "${FINAL_VCF}" \
    --output "${OUT_DIR}/neutral_callable_length.txt" \
    > "${LOG_DIR}/count_callable_length.log" 2>&1

echo "[6/6] Checking sample count"
sample_count="$(count_samples "${FINAL_VCF}")"

echo "Final VCF: ${FINAL_VCF}"
echo "Sample count: ${sample_count}"
echo "Intermediate 18-sample VCFs: ${SUBSET_DIR}"
echo "Filtered per-chromosome VCFs: ${FILTERED_DIR}"
echo "Callable length file: ${OUT_DIR}/neutral_callable_length.txt"

if [[ "${sample_count}" -ne 18 ]]; then
    echo "ERROR: expected 18 samples, got ${sample_count}" >&2
    echo "Check logs in: ${LOG_DIR}" >&2
    exit 1
fi

echo "Done. Logs are in: ${LOG_DIR}"
