#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="/mnt/f/project_2608_time"
CONFIG="${FSC_CONFIG:-config/config_2608_time.yaml}"
TOTAL_CORES="${TOTAL_CORES:-18}"
RUN_FSC_THREADS="${RUN_FSC_THREADS:-6}"
if [ "$#" -gt 0 ]; then
  TARGETS=("$@")
else
  TARGETS=("all")
fi

cd "${PROJECT_DIR}"

FSC_CONFIG="${CONFIG}" conda run -n project-fastsimcoal2 snakemake \
  -s Snakefile-722 \
  --cores "${TOTAL_CORES}" \
  --set-threads "run_fsc=${RUN_FSC_THREADS}" \
  --rerun-incomplete \
  --latency-wait 60 \
  --printshellcmds \
  -- "${TARGETS[@]}"
