#!/usr/bin/env python3

import argparse
from pathlib import Path

import pandas as pd
import yaml


LIKELIHOOD_COLUMNS = ["MaxEstLhood", "MaxObsLhood", "MaxSimLhood"]
TIME_COLUMNS = ["TDIV", "TFOUNDER", "TCONTACT", "TBOTEND"]


def add_calendar_columns(frame, config):
    rates = config.get("calendar_conversion", {}).get("generations_per_year", {})
    for time_col in TIME_COLUMNS:
        if time_col not in frame.columns:
            continue
        values = pd.to_numeric(frame[time_col], errors="coerce")
        for label, rate_range in rates.items():
            if not rate_range or len(rate_range) != 2:
                continue
            low_rate = float(rate_range[0])
            high_rate = float(rate_range[1])
            if low_rate <= 0 or high_rate <= 0:
                continue
            lo = min(low_rate, high_rate)
            hi = max(low_rate, high_rate)
            frame[f"{time_col}_years_{label}_min"] = values / hi
            frame[f"{time_col}_years_{label}_max"] = values / lo
    return frame


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--all-runs", required=True)
    parser.add_argument("--overall-best", required=True)
    args = parser.parse_args()

    with open(args.config, encoding="utf-8") as handle:
        config = yaml.safe_load(handle)

    frames = []
    for path in args.inputs:
        frames.append(pd.read_csv(path, sep="\t", dtype=str))
    all_runs = pd.concat(frames, ignore_index=True, sort=False)

    for column in LIKELIHOOD_COLUMNS:
        if column in all_runs.columns:
            all_runs[column] = pd.to_numeric(all_runs[column], errors="coerce")
    add_calendar_columns(all_runs, config)

    all_path = Path(args.all_runs)
    best_path = Path(args.overall_best)
    all_path.parent.mkdir(parents=True, exist_ok=True)
    best_path.parent.mkdir(parents=True, exist_ok=True)
    all_runs.to_csv(all_path, sep="\t", index=False)

    if "MaxEstLhood" in all_runs.columns:
        ok = all_runs[all_runs["status"].eq("ok") & all_runs["MaxEstLhood"].notna()]
        if len(ok):
            group_cols = ["projection", "model", "mu_token"]
            if "scenario" in ok.columns:
                group_cols.insert(1, "scenario")
            best = ok.sort_values("MaxEstLhood", ascending=False).groupby(
                group_cols, as_index=False
            ).head(1)
            best = best.sort_values("MaxEstLhood", ascending=False)
        else:
            best = all_runs.head(0)
    else:
        best = all_runs.head(0)
    best.to_csv(best_path, sep="\t", index=False)


if __name__ == "__main__":
    main()
