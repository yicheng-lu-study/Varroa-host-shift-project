#!/usr/bin/env python3

import argparse
import csv
from pathlib import Path


def read_table(path):
    text = Path(path).read_text(encoding="utf-8", errors="replace").strip().splitlines()
    rows = [line.strip() for line in text if line.strip()]
    if len(rows) < 2:
        return {}
    header = rows[0].split()
    values = rows[1].split()
    return dict(zip(header, values))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--projection", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--scenario", default="default")
    parser.add_argument("--mu-token", required=True)
    parser.add_argument("--replicate", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    candidates = sorted(run_dir.rglob("*.bestlhoods"))
    row = {
        "projection": args.projection,
        "scenario": args.scenario,
        "model": args.model,
        "mu_token": args.mu_token,
        "replicate": args.replicate,
        "status": "ok" if candidates else "missing_bestlhoods",
        "bestlhoods_path": str(candidates[0]) if candidates else "",
    }
    if candidates:
        row.update(read_table(candidates[0]))

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()), delimiter="\t")
        writer.writeheader()
        writer.writerow(row)


if __name__ == "__main__":
    main()
