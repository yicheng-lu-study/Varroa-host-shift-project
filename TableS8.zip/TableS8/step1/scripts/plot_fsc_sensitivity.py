#!/usr/bin/env python3

import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pandas as pd


SCENARIO_RE = re.compile(r"nf(?P<nfound>\d+)_tf(?P<tfounder>\d+)_(?P<mode>all|nosingleton)$")


def parse_scenarios(frame):
    parsed = frame["scenario"].str.extract(SCENARIO_RE)
    frame = frame.copy()
    frame["nfound_lower"] = parsed["nfound"].astype(int)
    frame["tfounder_lower"] = parsed["tfounder"].astype(int)
    frame["sfs_mode"] = parsed["mode"]
    frame["mu"] = frame["mu_token"].map({"2em10": "2e-10", "8em10": "8e-10"}).fillna(frame["mu_token"])
    return frame


def add_deltas(frame):
    frame = frame.copy()
    frame["MaxEstLhood"] = pd.to_numeric(frame["MaxEstLhood"], errors="coerce")
    for col in [
        "TFOUNDER",
        "NFOUND",
        "TFOUNDER_years_Ac_min",
        "TFOUNDER_years_Ac_max",
        "TFOUNDER_years_Am_min",
        "TFOUNDER_years_Am_max",
    ]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame["TFOUNDER_years_Ac_mid"] = (
        frame["TFOUNDER_years_Ac_min"] + frame["TFOUNDER_years_Ac_max"]
    ) / 2
    frame["TFOUNDER_years_Am_mid"] = (
        frame["TFOUNDER_years_Am_min"] + frame["TFOUNDER_years_Am_max"]
    ) / 2
    frame["deltaLogL"] = frame.groupby("sfs_mode")["MaxEstLhood"].transform("max") - frame[
        "MaxEstLhood"
    ]
    return frame


def marker_for_nfound(value):
    return {10: "o", 100: "s", 500: "^"}.get(int(value), "o")


def color_for_mu(value):
    return {"2e-10": "#1f77b4", "8e-10": "#d62728"}.get(str(value), "#555555")


def plot_axis(ax, sub, xcol, xlabel, title, logx=False):
    for mu in sorted(sub["mu"].dropna().unique()):
        mu_sub = sub[sub["mu"].eq(mu)].sort_values(xcol)
        ax.plot(
            mu_sub[xcol],
            mu_sub["deltaLogL"],
            color=color_for_mu(mu),
            linewidth=1.3,
            alpha=0.45,
            label=f"mu={mu}",
        )
    for _, row in sub.iterrows():
        ax.scatter(
            row[xcol],
            row["deltaLogL"],
            s=58,
            marker=marker_for_nfound(row["nfound_lower"]),
            color=color_for_mu(row["mu"]),
            edgecolor="black",
            linewidth=0.4,
            zorder=3,
        )
        if row["deltaLogL"] <= 15 or row["TFOUNDER"] >= 1000:
            ax.annotate(
                f"{int(row['TFOUNDER'])}",
                (row[xcol], row["deltaLogL"]),
                textcoords="offset points",
                xytext=(4, 4),
                fontsize=7,
            )
    for y, label in [(5, "5"), (15, "15"), (50, "50")]:
        ax.axhline(y, color="#888888", linewidth=0.8, linestyle="--", alpha=0.55)
        ax.text(
            0.995,
            y,
            label,
            transform=ax.get_yaxis_transform(),
            ha="right",
            va="bottom",
            fontsize=7,
            color="#666666",
        )
    if logx:
        ax.set_xscale("log")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("deltaLogL")
    ax.set_title(title)
    ax.grid(True, linewidth=0.4, alpha=0.35)


def make_plot(frame, xcol, xlabel, output, logx=False):
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.2), sharey=False)
    for ax, mode, title in zip(axes, ["all", "nosingleton"], ["All SFS", "No singleton"]):
        sub = frame[frame["sfs_mode"].eq(mode)]
        plot_axis(ax, sub, xcol, xlabel, title, logx=logx)
    mu_handles = [
        Line2D([0], [0], color=color_for_mu("2e-10"), marker="o", label="mu=2e-10"),
        Line2D([0], [0], color=color_for_mu("8e-10"), marker="o", label="mu=8e-10"),
    ]
    nfound_handles = [
        Line2D([0], [0], color="#333333", marker="o", linestyle="None", label="NFOUND lower=10"),
        Line2D([0], [0], color="#333333", marker="s", linestyle="None", label="NFOUND lower=100"),
        Line2D([0], [0], color="#333333", marker="^", linestyle="None", label="NFOUND lower=500"),
    ]
    fig.legend(
        handles=mu_handles + nfound_handles,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.92),
        ncol=5,
        frameon=False,
        fontsize=8,
    )
    fig.suptitle("fastsimcoal2 founder-time sensitivity", y=0.985, fontsize=14)
    fig.text(
        0.5,
        0.01,
        "Horizontal dashed lines are project working guides, not fastsimcoal2 official cutoffs. "
        "Point labels show TFOUNDER in generations for near-best or older solutions.",
        ha="center",
        fontsize=8,
        color="#444444",
    )
    fig.tight_layout(rect=(0, 0.06, 1, 0.86))
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--overall-best", required=True)
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    frame = pd.read_csv(args.overall_best, sep="\t")
    frame = add_deltas(parse_scenarios(frame))
    frame = frame.sort_values(["sfs_mode", "TFOUNDER", "mu", "nfound_lower"])
    frame.to_csv(outdir / "founder_sensitivity_plot_data.tsv", sep="\t", index=False)

    make_plot(
        frame,
        "TFOUNDER",
        "TFOUNDER generations",
        outdir / "deltaLogL_vs_TFOUNDER_generations.png",
        logx=True,
    )
    make_plot(
        frame,
        "TFOUNDER_years_Am_mid",
        "TFOUNDER years, Am generation rate midpoint",
        outdir / "deltaLogL_vs_TFOUNDER_years_Am.png",
        logx=True,
    )
    make_plot(
        frame,
        "TFOUNDER_years_Ac_mid",
        "TFOUNDER years, Ac generation rate midpoint",
        outdir / "deltaLogL_vs_TFOUNDER_years_Ac.png",
        logx=True,
    )


if __name__ == "__main__":
    main()
