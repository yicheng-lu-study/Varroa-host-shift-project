#!/usr/bin/env python3

import argparse
import gzip
import math
import tempfile
from pathlib import Path

import dadi
import numpy as np
import yaml


def parse_projection(token):
    return [int(x) for x in str(token).replace(",", "x").split("x")]


def read_callable_length(path):
    rows = [x.strip() for x in Path(path).read_text().splitlines() if x.strip()]
    if len(rows) == 1:
        return float(rows[0])
    return float(rows[1].split()[0])


def open_text(path):
    return gzip.open(path, "rt") if str(path).endswith(".gz") else open(path, encoding="utf-8")


def write_variant_only_vcf(input_vcf, output_vcf):
    kept = 0
    with open_text(input_vcf) as src, open(output_vcf, "w", encoding="utf-8") as dst:
        for line in src:
            if line.startswith("#"):
                dst.write(line)
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 5:
                continue
            alt = fields[4]
            if alt in {".", ""}:
                continue
            dst.write(line)
            kept += 1
    return kept


def round_preserving_sum(values):
    flat = np.asarray(values, dtype=float).ravel()
    floored = np.floor(flat)
    target = int(round(float(np.sum(flat))))
    remainder = target - int(np.sum(floored))
    if remainder > 0:
        order = np.argsort(-(flat - floored))
        floored[order[:remainder]] += 1
    return floored.reshape(values.shape).astype(np.int64)


def write_joint_maf(path, fs, prefix):
    if fs.ndim != 2:
        raise ValueError("fastsimcoal2 joint MAF writer expects a 2D spectrum")

    n0 = fs.shape[0] - 1
    n1 = fs.shape[1] - 1
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w", encoding="utf-8") as handle:
        handle.write("1 observations\n")
        handle.write("\t" + "\t".join(f"d0_{i}" for i in range(n0 + 1)) + "\n")
        for j in range(n1 + 1):
            row = [str(int(fs[i, j])) for i in range(n0 + 1)]
            handle.write(f"d1_{j}\t" + "\t".join(row) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--projection", required=True)
    parser.add_argument("--vcf", required=True)
    parser.add_argument("--callable-length", required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--output-obs", required=True)
    parser.add_argument("--output-summary", required=True)
    args = parser.parse_args()

    with open(args.config, encoding="utf-8") as handle:
        config = yaml.safe_load(handle)

    observed = config["observed"]
    projection = parse_projection(args.projection)
    tmp_root = Path(args.output_obs).parent / "tmp"
    tmp_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="fsc_variant_only_", dir=tmp_root) as tmpdir:
        variant_vcf = Path(tmpdir) / "variants.vcf"
        variant_records = write_variant_only_vcf(args.vcf, variant_vcf)
        data_dict = dadi.Misc.make_data_dict_vcf(str(variant_vcf), observed["population_table"])
    fs = dadi.Spectrum.from_data_dict(
        data_dict,
        pop_ids=observed["pop_ids"],
        projections=projection,
        polarized=bool(observed.get("polarized", False)),
    )

    arr = np.asarray(fs.filled(0), dtype=float)
    arr[arr < 0] = 0
    segregating_sites = float(np.sum(arr) - arr[0, 0])

    callable_length = read_callable_length(args.callable_length)
    if bool(observed.get("include_monomorphic", True)):
        monomorphic = max(callable_length - segregating_sites, 0.0)
        arr[0, 0] = monomorphic

    if bool(observed.get("round_counts", True)):
        arr = round_preserving_sum(arr)
    else:
        if not np.allclose(arr, np.round(arr)):
            raise ValueError("fastsimcoal2 OBS counts should be integer; enable round_counts")
        arr = np.round(arr).astype(np.int64)

    write_joint_maf(args.output_obs, arr, args.prefix)

    summary = Path(args.output_summary)
    summary.parent.mkdir(parents=True, exist_ok=True)
    with summary.open("w", encoding="utf-8") as handle:
        handle.write("stat\tvalue\n")
        handle.write(f"projection\t{args.projection}\n")
        handle.write(f"vcf\t{args.vcf}\n")
        handle.write(f"variant_records_for_sfs\t{variant_records}\n")
        handle.write(f"sample_sizes\t{','.join(map(str, projection))}\n")
        handle.write(f"folded\t{bool(fs.folded)}\n")
        handle.write(f"callable_length\t{callable_length:.12g}\n")
        handle.write(f"segregating_sites_projected\t{segregating_sites:.12g}\n")
        handle.write(f"monomorphic_count\t{int(arr[0, 0])}\n")
        handle.write(f"total_count\t{int(np.sum(arr))}\n")
        handle.write(f"obs\t{args.output_obs}\n")


if __name__ == "__main__":
    main()
