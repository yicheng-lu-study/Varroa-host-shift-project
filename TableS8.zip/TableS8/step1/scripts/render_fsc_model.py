#!/usr/bin/env python3

import argparse
import copy
from pathlib import Path

import yaml


MODEL_MIGRATION = {
    "div_nobot": "hostjump_none",
    "mig_nobot": "hostjump_asymmetric",
    "div_botgrowth": "hostjump_growth_none",
    "mig_botgrowth": "hostjump_growth_asymmetric",
    "split_no_migration": "none",
    "split_symmetric_migration": "symmetric",
    "split_asymmetric_migration": "asymmetric",
    "recent_founder_no_migration": "founder_none",
    "recent_founder_symmetric_migration": "founder_symmetric",
    "recent_founder_asymmetric_migration": "founder_asymmetric",
    "old_split_recent_symmetric_contact": "recent_symmetric",
    "old_split_recent_asymmetric_contact": "recent_asymmetric",
}


def parse_projection(token):
    return [int(x) for x in str(token).replace(",", "x").split("x")]


def mu_from_token(token):
    token = str(token)
    mantissa, exponent = token.split("e", 1)
    mantissa = float(mantissa.replace("p", "."))
    sign = -1 if exponent.startswith("m") else 1
    return mantissa * (10 ** (sign * int(exponent[1:])))


def migration_matrix(kind, active=True):
    if not active or kind in {"none", "founder_none", "hostjump_none", "hostjump_growth_none"}:
        return ["0 0", "0 0"]
    if kind in {"hostjump_asymmetric", "hostjump_growth_asymmetric"}:
        return ["0 M0TO1", "M1TO0 0"]
    if kind in {"symmetric", "recent_symmetric", "founder_symmetric"}:
        return ["0 MIG12", "MIG12 0"]
    if kind in {"asymmetric", "recent_asymmetric", "founder_asymmetric"}:
        return ["0 MIG12", "MIG21 0"]
    raise ValueError(f"unsupported migration model: {kind}")


def historical_events(model):
    # Events are backward in time: time, source, sink, migrants, new size,
    # new growth rate, migration matrix, optional absoluteResize.
    if model == "div_nobot":
        return ["TFOUNDER 0 1 1 RESJUMP 0 0"]
    if model == "mig_nobot":
        return ["TFOUNDER 0 1 1 RESJUMP 0 1"]
    if model == "div_botgrowth":
        return [
            "TBOTEND 0 0 0 RESBOT 0 0",
            "TFOUNDER 0 1 1 RESJUMP 0 0",
        ]
    if model == "mig_botgrowth":
        return [
            "TBOTEND 0 0 0 RESBOT 0 1",
            "TFOUNDER 0 1 1 RESJUMP 0 1",
        ]
    if model.startswith("old_split_recent"):
        return [
            "TCONTACT 0 0 0 1 0 1",
            "TDIV 1 0 1 NANC 0 1 absoluteResize",
        ]
    if model.startswith("recent_founder"):
        return [
            "TBOTEND 1 1 0 NFOUND 0 0 absoluteResize",
            "TFOUNDER 1 0 1 NANC 0 1 absoluteResize",
        ]
    return ["TDIV 1 0 1 NANC 0 1 absoluteResize"]


def render_tpl(model, projection, mu):
    kind = MODEL_MIGRATION[model]
    if kind in {"hostjump_none", "hostjump_growth_none"}:
        matrices = []
    else:
        matrices = [
            migration_matrix(kind, active=True),
            migration_matrix(kind, active=False),
        ]
    if kind in {"hostjump_none", "hostjump_growth_none"}:
        size_lines = ["NPOP0", "NPOP1"]
        growth_lines = ["GROWTH0" if kind == "hostjump_growth_none" else "0", "0"]
    elif kind in {"hostjump_asymmetric", "hostjump_growth_asymmetric"}:
        size_lines = ["NPOP0", "NPOP1"]
        growth_lines = ["GROWTH0" if kind == "hostjump_growth_asymmetric" else "0", "0"]
    else:
        size_lines = ["NPOP1", "NPOP2"]
        growth_lines = ["0", "0"]

    lines = [
        "//Parameters for the coalescence simulation program : fsimcoal2.exe",
        "2 samples to simulate :",
        "//Population effective sizes (number of genes)",
        *size_lines,
        "//Samples sizes and samples age ",
        str(projection[0]),
        str(projection[1]),
        "//Growth rates\t: negative growth implies population expansion",
        *growth_lines,
        "//Number of migration matrices : 0 implies no migration between demes",
        str(len(matrices)),
    ]

    for idx, matrix in enumerate(matrices):
        if idx == 0:
            lines.append("//Migration matrix 0")
        elif idx == 1:
            lines.append("//Migration matrix 1: No migration")
        lines.extend(matrix)

    events = historical_events(model)
    lines.extend([
        "//historical event: time, source, sink, migrants, new deme size, new growth rate, migration matrix index",
        f"{len(events)} historical event",
        *events,
        "//Number of independent loci [chromosome] ",
        "1 0",
        "//Per chromosome: Number of contiguous linkage Block: a block is a set of contiguous loci",
        "1",
        "//per Block:data type, number of loci, per generation recombination and mutation rates and optional parameters",
        f"FREQ  1   0   {mu:.12g} OUTEXP",
    ])
    return "\n".join(lines) + "\n"


def scenario_spec(config, scenario):
    for spec in config.get("analysis", {}).get("scenarios", []):
        if spec.get("name") == scenario:
            return spec
    if scenario == "default":
        return {}
    raise ValueError(f"unknown scenario: {scenario}")


def render_est(config, model, scenario="default"):
    params = config["fsc_parameters"]["by_model"][model]
    defaults = copy.deepcopy(config["fsc_parameters"]["defaults"])
    overrides = scenario_spec(config, scenario).get("parameter_overrides", {})
    for name, values in overrides.items():
        if name not in defaults:
            raise ValueError(f"scenario {scenario} overrides unknown parameter: {name}")
        defaults[name].update(values)

    lines = [
        "// fastsimcoal2 parameter file generated by scripts/render_fsc_model.py",
        "[PARAMETERS]",
        "//#isInt? #name #dist. #min #max #output",
    ]
    for name in params:
        spec = defaults[name]
        upper = spec["upper"]
        suffix = "output bounded" if name.startswith("T") else "output"
        lines.append(
            f'{int(spec["is_int"])} {name} {spec["dist"]} '
            f'{spec["lower"]} {upper} {suffix}'
        )

    lines.extend(["", "[RULES]"])
    if model in {"div_botgrowth", "mig_botgrowth"}:
        lines.append("NFOUND < NPOP0")
        lines.append("NFOUND < NPOP1")
        lines.append("TBOTEND < TFOUNDER")
    if "TCONTACT" in params and "TDIV" in params:
        lines.append("TCONTACT < TDIV")

    lines.extend(["", "[COMPLEX PARAMETERS]"])
    if model in {"div_nobot", "mig_nobot"}:
        lines.append("0 RESJUMP = NPOP1/NPOP0 output")
    if model in {"div_botgrowth", "mig_botgrowth"}:
        lines.append("0 RESBOT = NFOUND/NPOP0 output")
        lines.append("0 RESJUMP = NPOP1/NFOUND output")
    if model in {"mig_nobot", "mig_botgrowth"}:
        lines.append("0 M0TO1 = N0M1/NPOP0 output")
        lines.append("0 M1TO0 = N1M0/NPOP1 output")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--scenario", default="default")
    parser.add_argument("--projection", required=True)
    parser.add_argument("--mu-token", required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--output-tpl", required=True)
    parser.add_argument("--output-est", required=True)
    args = parser.parse_args()

    with open(args.config, encoding="utf-8") as handle:
        config = yaml.safe_load(handle)

    if args.model not in MODEL_MIGRATION:
        raise ValueError(f"unknown model: {args.model}")

    projection = parse_projection(args.projection)
    mu = mu_from_token(args.mu_token)

    tpl = Path(args.output_tpl)
    est = Path(args.output_est)
    tpl.parent.mkdir(parents=True, exist_ok=True)
    est.parent.mkdir(parents=True, exist_ok=True)
    tpl.write_text(render_tpl(args.model, projection, mu), encoding="utf-8")
    est.write_text(render_est(config, args.model, args.scenario), encoding="utf-8")


if __name__ == "__main__":
    main()
