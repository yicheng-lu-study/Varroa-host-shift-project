#!/usr/bin/env python3

import argparse
import gzip
from pathlib import Path


def open_text(path):
    return gzip.open(path, "rt") if str(path).endswith(".gz") else open(path, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vcf", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    count = 0
    with open_text(args.vcf) as handle:
        for line in handle:
            if line and not line.startswith("#"):
                count += 1

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(f"{count}\n", encoding="utf-8")


if __name__ == "__main__":
    main()
