#!/usr/bin/env python3

import argparse
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--population-table", required=True)
    parser.add_argument("--pop-ids", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    wanted = set(args.pop_ids)
    samples = []
    with open(args.population_table, encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            sample, pop = line.split()[:2]
            if pop in wanted:
                samples.append(sample)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(samples) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
